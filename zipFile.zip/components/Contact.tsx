import React from 'react';
import { MapPin, Phone, Mail, Send } from 'lucide-react';

interface ContactProps {
  content: {
    title: string;
    subtitle: string;
    form: {
      name: string;
      email: string;
      phone: string;
      message: string;
      submit: string;
    };
    info: {
      addressLabel: string;
      address: string;
      phoneLabel: string;
      emailLabel: string;
    };
  };
}

const Contact: React.FC<ContactProps> = ({ content }) => {
  return (
    <section className="py-20 bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4">
            {content.title}
          </h2>
          <p className="text-slate-600 dark:text-slate-400">
            {content.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="bg-white dark:bg-slate-800 p-8 rounded-2xl shadow-lg border border-slate-100 dark:border-slate-700">
            <form onSubmit={(e) => e.preventDefault()} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  {content.form.name}
                </label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-600 focus:border-corporate-gold focus:ring-1 focus:ring-corporate-gold outline-none transition-colors dark:text-white"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                    {content.form.email}
                  </label>
                  <input 
                    type="email" 
                    className="w-full px-4 py-3 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-600 focus:border-corporate-gold focus:ring-1 focus:ring-corporate-gold outline-none transition-colors dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                    {content.form.phone}
                  </label>
                  <input 
                    type="tel" 
                    className="w-full px-4 py-3 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-600 focus:border-corporate-gold focus:ring-1 focus:ring-corporate-gold outline-none transition-colors dark:text-white"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  {content.form.message}
                </label>
                <textarea 
                  rows={4} 
                  className="w-full px-4 py-3 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-600 focus:border-corporate-gold focus:ring-1 focus:ring-corporate-gold outline-none transition-colors dark:text-white resize-none"
                ></textarea>
              </div>
              <button 
                type="submit" 
                className="w-full py-4 bg-corporate-gold hover:bg-amber-600 text-white font-bold rounded-lg shadow-md transition-colors flex items-center justify-center gap-2"
              >
                <Send size={18} className="rtl:rotate-180" />
                {content.form.submit}
              </button>
            </form>
          </div>

          {/* Info & Map */}
          <div className="flex flex-col gap-8">
            {/* Info Cards */}
            <div className="grid grid-cols-1 gap-4">
              <div className="flex items-start gap-4 bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm">
                <div className="p-3 rounded-full bg-blue-50 dark:bg-slate-700 text-corporate-gold">
                  <MapPin size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white mb-1">{content.info.addressLabel}</h4>
                  <p className="text-slate-600 dark:text-slate-400">{content.info.address}</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4 bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm">
                <div className="p-3 rounded-full bg-blue-50 dark:bg-slate-700 text-corporate-gold">
                  <Phone size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white mb-1">{content.info.phoneLabel}</h4>
                  <p className="text-slate-600 dark:text-slate-400">+971 2 123 4567</p>
                </div>
              </div>

              <div className="flex items-start gap-4 bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm">
                <div className="p-3 rounded-full bg-blue-50 dark:bg-slate-700 text-corporate-gold">
                  <Mail size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white mb-1">{content.info.emailLabel}</h4>
                  <p className="text-slate-600 dark:text-slate-400">info@asia-business.ae</p>
                </div>
              </div>
            </div>

            {/* Map Placeholder */}
            <div className="flex-grow min-h-[300px] bg-slate-200 dark:bg-slate-700 rounded-2xl overflow-hidden relative">
               <img 
                src="https://picsum.photos/seed/abudhabimap/800/600" 
                alt="Map Location" 
                className="w-full h-full object-cover opacity-80"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                 <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur px-6 py-3 rounded-lg shadow-lg">
                    <span className="font-bold text-slate-800 dark:text-white flex items-center gap-2">
                        <MapPin className="text-red-500" />
                        Google Maps Integration
                    </span>
                 </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;