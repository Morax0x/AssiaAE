import React from 'react';
import { Building, Shield, Scale, FileCheck, Landmark } from 'lucide-react';

interface GovernmentBarProps {
  content: {
    title: string;
  };
}

const GovernmentBar: React.FC<GovernmentBarProps> = ({ content }) => {
  // Using generic icons to represent government entities to avoid copyright issues with real logos
  const entities = [
    { icon: Building, label: "MOHRE / TASHEEL" },
    { icon: Landmark, label: "Dept. of Economy" },
    { icon: Shield, label: "Federal Authority" },
    { icon: Scale, label: "Judicial Dept." },
    { icon: FileCheck, label: "Notary Public" },
  ];

  return (
    <section className="bg-white dark:bg-slate-800 py-10 border-b border-slate-200 dark:border-slate-700 shadow-sm relative z-20 -mt-2">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-center text-slate-500 dark:text-slate-400 text-sm uppercase tracking-widest font-semibold mb-8">
          {content.title}
        </p>
        <div className="flex flex-wrap justify-center gap-8 md:gap-16 opacity-70 hover:opacity-100 transition-opacity duration-300">
          {entities.map((item, idx) => (
            <div key={idx} className="flex flex-col items-center gap-2 group">
              <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 group-hover:bg-slate-200 dark:group-hover:bg-slate-600 group-hover:scale-110 transition-all duration-300">
                <item.icon size={32} />
              </div>
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400 group-hover:text-slate-800 dark:group-hover:text-slate-200 text-center max-w-[100px]">
                {item.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default GovernmentBar;