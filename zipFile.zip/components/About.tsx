import React from 'react';
import { CheckCircle2 } from 'lucide-react';

interface AboutProps {
  content: {
    title: string;
    subtitle: string;
    description1: string;
    description2: string;
    stats: { label: string; value: string }[];
  };
  summaryMode?: boolean;
}

const About: React.FC<AboutProps> = ({ content, summaryMode }) => {
  return (
    <section className="py-20 bg-white dark:bg-slate-800 transition-colors duration-300 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          
          {/* Image Side */}
          <div className="w-full lg:w-1/2 relative">
            <div className="absolute top-4 -left-4 w-full h-full bg-slate-100 dark:bg-slate-700 rounded-2xl transform -rotate-2"></div>
            <div className="absolute -bottom-4 -right-4 w-full h-full border-2 border-corporate-gold rounded-2xl transform rotate-2"></div>
            <img 
              src="https://picsum.photos/seed/officeuae/800/600" 
              alt="Our Office" 
              className="relative rounded-2xl shadow-xl w-full h-[400px] object-cover z-10"
            />
          </div>

          {/* Text Side */}
          <div className="w-full lg:w-1/2">
            <span className="text-corporate-gold font-bold uppercase tracking-wider text-sm mb-2 block">
              {content.subtitle}
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-6">
              {content.title}
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
              {content.description1}
            </p>
            {!summaryMode && (
              <p className="text-lg text-slate-600 dark:text-slate-300 leading-relaxed mb-8">
                {content.description2}
              </p>
            )}

            <div className="grid grid-cols-3 gap-4 border-t border-slate-200 dark:border-slate-700 pt-8 mt-8">
              {content.stats.map((stat, idx) => (
                <div key={idx} className="text-center lg:text-start rtl:lg:text-start">
                  <div className="text-2xl md:text-3xl font-bold text-corporate-gold mb-1">
                    {stat.value}
                  </div>
                  <div className="text-sm text-slate-500 dark:text-slate-400 font-medium">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;