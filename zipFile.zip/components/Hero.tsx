import React from 'react';
import { ChevronRight, ArrowRight } from 'lucide-react';

interface HeroProps {
  content: {
    title: string;
    subtitle: string;
    ctaPrimary: string;
    ctaSecondary: string;
  };
  onCtaClick: () => void;
  onContactClick: () => void;
}

const Hero: React.FC<HeroProps> = ({ content, onCtaClick, onContactClick }) => {
  return (
    <section className="relative w-full h-[600px] md:h-[700px] flex items-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://picsum.photos/seed/abudhabicity/1920/1080" 
          alt="Abu Dhabi Skyline"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 via-slate-900/70 to-slate-900/40 rtl:bg-gradient-to-l"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="max-w-2xl text-start rtl:text-start">
          <div className="inline-block px-4 py-1 mb-6 rounded-full bg-amber-500/20 border border-amber-500/30 backdrop-blur-sm">
            <span className="text-amber-400 text-sm font-semibold tracking-wide uppercase">
              Official Government Services Partner
            </span>
          </div>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight drop-shadow-lg">
            {content.title}
          </h1>
          
          <p className="text-lg md:text-xl text-slate-200 mb-8 leading-relaxed max-w-lg drop-shadow-md">
            {content.subtitle}
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <button
              onClick={onCtaClick}
              className="px-8 py-4 bg-corporate-gold hover:bg-amber-600 text-white font-bold rounded-lg shadow-lg shadow-amber-900/20 transition-all transform hover:-translate-y-1 flex items-center justify-center gap-2"
            >
              {content.ctaPrimary}
              <ArrowRight size={20} className="rtl:rotate-180" />
            </button>
            
            <button
              onClick={onContactClick}
              className="px-8 py-4 bg-transparent border-2 border-white text-white hover:bg-white hover:text-slate-900 font-bold rounded-lg transition-all flex items-center justify-center gap-2"
            >
              {content.ctaSecondary}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;