import React from 'react';
import { ServiceItem } from '../types';
import { ArrowRight } from 'lucide-react';

interface ServicesProps {
  content: {
    title: string;
    subtitle: string;
    items: ServiceItem[];
  };
  limit?: number;
  onViewAll?: () => void;
}

const Services: React.FC<ServicesProps> = ({ content, limit, onViewAll }) => {
  const displayItems = limit ? content.items.slice(0, limit) : content.items;

  return (
    <section className="py-20 bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-corporate-blue dark:text-white mb-4">
            {content.title}
          </h2>
          <div className="w-20 h-1 bg-corporate-gold mx-auto mb-6"></div>
          <p className="text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
            {content.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayItems.map((item) => (
            <div 
              key={item.id} 
              className="bg-white dark:bg-slate-800 rounded-xl shadow-sm hover:shadow-xl p-8 transition-all duration-300 transform hover:-translate-y-2 border border-slate-100 dark:border-slate-700 group"
            >
              <div className="w-14 h-14 rounded-lg bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center text-corporate-gold mb-6 group-hover:bg-corporate-gold group-hover:text-white transition-colors duration-300">
                <item.icon size={28} />
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-3 group-hover:text-corporate-gold transition-colors">
                {item.title}
              </h3>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed mb-6">
                {item.description}
              </p>
            </div>
          ))}
        </div>

        {limit && (
          <div className="text-center mt-12">
            <button 
              onClick={onViewAll}
              className="inline-flex items-center gap-2 text-corporate-gold font-bold hover:text-amber-700 dark:hover:text-amber-400 transition-colors"
            >
              {/* Note: In a real app, translate this "View All" or pass it in props */}
              <span className="text-lg">View All Services</span>
              <ArrowRight size={20} className="rtl:rotate-180" />
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default Services;