import React, { useState } from 'react';
import { Language, View } from '../types';
import { Menu, X, Moon, Sun, Globe } from 'lucide-react';

interface NavbarProps {
  lang: Language;
  setLang: (l: Language) => void;
  view: View;
  setView: (v: View) => void;
  darkMode: boolean;
  setDarkMode: (d: boolean) => void;
  content: {
    home: string;
    services: string;
    about: string;
    contact: string;
    langLabel: string;
  };
}

const Navbar: React.FC<NavbarProps> = ({ 
  lang, 
  setLang, 
  view, 
  setView, 
  darkMode, 
  setDarkMode, 
  content 
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { id: View; label: string }[] = [
    { id: 'home', label: content.home },
    { id: 'services', label: content.services },
    { id: 'about', label: content.about },
    { id: 'contact', label: content.contact },
  ];

  const handleLangToggle = () => {
    setLang(lang === 'en' ? 'ar' : 'en');
  };

  const Logo = () => (
    <div className="flex items-center gap-2 cursor-pointer" onClick={() => setView('home')}>
      <div className="w-8 h-8 md:w-10 md:h-10 bg-corporate-gold rounded-lg flex items-center justify-center shadow-lg transform rotate-3">
        <span className="text-white font-bold text-lg md:text-xl">A</span>
      </div>
      <div className="flex flex-col">
        <span className="text-lg md:text-xl font-bold text-corporate-blue dark:text-white leading-none">
          {lang === 'en' ? 'ASIA' : 'آسيا'}
        </span>
        <span className="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-widest">
          {lang === 'en' ? 'Business Services' : 'لخدمات الأعمال'}
        </span>
      </div>
    </div>
  );

  return (
    <nav className="fixed w-full z-50 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md shadow-sm border-b border-slate-200 dark:border-slate-800 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 md:h-20 items-center">
          
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <Logo />
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8 rtl:space-x-reverse">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setView(item.id)}
                className={`${
                  view === item.id 
                    ? 'text-corporate-gold font-bold' 
                    : 'text-slate-600 dark:text-slate-300 hover:text-corporate-gold dark:hover:text-corporate-gold'
                } transition-colors duration-200 text-sm uppercase tracking-wide px-2 py-1`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Actions */}
          <div className="hidden md:flex items-center space-x-4 rtl:space-x-reverse">
            <button
              onClick={handleLangToggle}
              className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors text-sm font-medium"
            >
              <Globe size={16} />
              <span>{content.langLabel}</span>
            </button>
            
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Toggle Dark Mode"
            >
              {darkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center gap-4">
             <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-1 text-slate-600 dark:text-slate-300"
            >
              {darkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white p-2"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 shadow-xl">
          <div className="px-4 pt-2 pb-6 space-y-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setView(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`block w-full text-start px-3 py-3 rounded-md text-base font-medium ${
                  view === item.id
                    ? 'bg-amber-50 dark:bg-slate-800 text-corporate-gold'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                {item.label}
              </button>
            ))}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 mt-2">
              <button
                onClick={() => {
                   handleLangToggle();
                   setMobileMenuOpen(false);
                }}
                className="flex items-center gap-2 w-full px-3 py-3 text-slate-600 dark:text-slate-300 hover:text-corporate-gold"
              >
                <Globe size={18} />
                {content.langLabel}
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;