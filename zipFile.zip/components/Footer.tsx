import React from 'react';
import { View } from '../types';
import { Facebook, Twitter, Linkedin, Instagram } from 'lucide-react';

interface FooterProps {
  content: {
    company: string;
    description: string;
    rights: string;
  };
  nav: {
    home: string;
    services: string;
    about: string;
    contact: string;
  };
  onNavClick: (view: View) => void;
}

const Footer: React.FC<FooterProps> = ({ content, nav, onNavClick }) => {
  return (
    <footer className="bg-corporate-blue text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          
          {/* Company Info */}
          <div>
             <div className="flex items-center gap-2 mb-6">
                <div className="w-10 h-10 bg-corporate-gold rounded-lg flex items-center justify-center">
                    <span className="text-white font-bold text-xl">A</span>
                </div>
                <span className="text-2xl font-bold">{content.company}</span>
             </div>
            <p className="text-slate-400 leading-relaxed mb-6">
              {content.description}
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-corporate-gold transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-corporate-gold transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-corporate-gold transition-colors">
                <Twitter size={20} />
              </a>
               <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-corporate-gold transition-colors">
                <Instagram size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-6 border-b border-slate-700 pb-2 inline-block">Quick Links</h3>
            <ul className="space-y-4">
              <li>
                <button onClick={() => onNavClick('home')} className="text-slate-400 hover:text-white transition-colors">
                  {nav.home}
                </button>
              </li>
              <li>
                <button onClick={() => onNavClick('services')} className="text-slate-400 hover:text-white transition-colors">
                  {nav.services}
                </button>
              </li>
              <li>
                <button onClick={() => onNavClick('about')} className="text-slate-400 hover:text-white transition-colors">
                  {nav.about}
                </button>
              </li>
              <li>
                <button onClick={() => onNavClick('contact')} className="text-slate-400 hover:text-white transition-colors">
                  {nav.contact}
                </button>
              </li>
            </ul>
          </div>

           {/* Newsletter / Map Info */}
          <div>
            <h3 className="text-lg font-bold mb-6 border-b border-slate-700 pb-2 inline-block">Official Hours</h3>
             <ul className="space-y-4 text-slate-400">
                <li className="flex justify-between">
                    <span>Monday - Thursday:</span>
                    <span className="text-white">8:00 AM - 5:00 PM</span>
                </li>
                <li className="flex justify-between">
                    <span>Friday:</span>
                    <span className="text-white">8:00 AM - 12:00 PM</span>
                </li>
                <li className="flex justify-between">
                    <span>Saturday - Sunday:</span>
                    <span className="text-white">Closed</span>
                </li>
             </ul>
          </div>

        </div>

        <div className="border-t border-slate-800 pt-8 text-center text-slate-500 text-sm">
          <p>{content.rights}</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;