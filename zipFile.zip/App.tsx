import React, { useState, useEffect } from 'react';
import { APP_CONTENT } from './constants';
import { Language, View } from './types';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import About from './components/About';
import Contact from './components/Contact';
import Footer from './components/Footer';
import GovernmentBar from './components/GovernmentBar';

function App() {
  const [lang, setLang] = useState<Language>('en');
  const [view, setView] = useState<View>('home');
  const [darkMode, setDarkMode] = useState(false);

  // Handle document direction and font family based on language
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    if (lang === 'ar') {
      document.body.classList.add('font-arabic');
      document.body.classList.remove('font-sans');
    } else {
      document.body.classList.add('font-sans');
      document.body.classList.remove('font-arabic');
    }
  }, [lang]);

  // Handle dark mode class on html element
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const content = APP_CONTENT[lang];

  const handleNavClick = (newView: View) => {
    setView(newView);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
      <Navbar 
        lang={lang} 
        setLang={setLang} 
        view={view} 
        setView={handleNavClick} 
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        content={content.nav}
      />

      <main className="flex-grow pt-16">
        {view === 'home' && (
          <>
            <Hero 
              content={content.hero} 
              onCtaClick={() => handleNavClick('services')} 
              onContactClick={() => handleNavClick('contact')}
            />
            <GovernmentBar content={content.trust} />
            <Services content={content.services} limit={3} onViewAll={() => handleNavClick('services')} />
            <About content={content.about} summaryMode />
          </>
        )}

        {view === 'services' && (
          <Services content={content.services} />
        )}

        {view === 'about' && (
          <About content={content.about} />
        )}

        {view === 'contact' && (
          <Contact content={content.contact} />
        )}
      </main>

      <Footer content={content.footer} nav={content.nav} onNavClick={handleNavClick} />
    </div>
  );
}

export default App;