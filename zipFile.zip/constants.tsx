import { Content } from './types';
import { 
  Briefcase, 
  FileText, 
  Globe, 
  Scale, 
  ShieldCheck, 
  Building2 
} from 'lucide-react';

export const APP_CONTENT: Content = {
  en: {
    nav: {
      home: 'Home',
      services: 'Services',
      about: 'About Us',
      contact: 'Contact Us',
      langLabel: 'العربية',
    },
    hero: {
      title: 'Facilitating Your Business Success in the UAE',
      subtitle: 'Your trusted partner for government transactions, PRO services, and business setup in Abu Dhabi.',
      ctaPrimary: 'Our Services',
      ctaSecondary: 'Contact Us',
    },
    trust: {
      title: 'Trusted by Government Agencies',
    },
    services: {
      title: 'Our Expertise',
      subtitle: 'Comprehensive solutions for individuals and corporations.',
      items: [
        {
          id: 's1',
          icon: Building2,
          title: 'Business Setup',
          description: 'Complete assistance with DED trade licenses, approvals, and company formation in mainland and free zones.',
        },
        {
          id: 's2',
          icon: FileText,
          title: 'PRO Services',
          description: 'Efficient processing of work permits, employment contracts, and labor cards with MOHRE (Tasheel).',
        },
        {
          id: 's3',
          icon: ShieldCheck,
          title: 'Visa & Immigration',
          description: 'Fast-track processing for Golden Visas, residence visas, and family sponsorship.',
        },
        {
          id: 's4',
          icon: Globe,
          title: 'Passport Services',
          description: 'Handling passport renewals and official documentation for various nationalities.',
        },
        {
          id: 's5',
          icon: Scale,
          title: 'Legal Translation',
          description: 'Certified translation services for all official documents required by UAE courts and ministries.',
        },
        {
          id: 's6',
          icon: Briefcase,
          title: 'Corporate Support',
          description: 'Ongoing support for corporate bank account opening and government compliance.',
        },
      ],
    },
    about: {
      title: 'About Asia for Business',
      subtitle: 'Excellence, Integrity, and Efficiency',
      description1: 'Asia for Business Services is a premier document clearing and business facilitation company based in Abu Dhabi. We bridge the gap between businesses and government entities, ensuring smooth and compliant operations.',
      description2: 'With years of experience and a team of dedicated professionals, we understand the nuances of UAE labor laws and immigration procedures. We are proud to be licensed and trusted by multiple government agencies.',
      stats: [
        { label: 'Years Experience', value: '10+' },
        { label: 'Happy Clients', value: '500+' },
        { label: 'Transactions', value: '10k+' },
      ],
    },
    contact: {
      title: 'Get in Touch',
      subtitle: 'Visit our office or send us a message.',
      form: {
        name: 'Full Name',
        email: 'Email Address',
        phone: 'Phone Number',
        message: 'Your Message',
        submit: 'Send Message',
      },
      info: {
        addressLabel: 'Our Office',
        address: 'Al Falah Street, Abu Dhabi, UAE',
        phoneLabel: 'Call Us',
        emailLabel: 'Email Us',
      },
    },
    footer: {
      company: 'Asia for Business Services',
      description: 'Your gateway to seamless government services in the UAE.',
      rights: '© 2024 Asia for Business Services. All rights reserved.',
    },
  },
  ar: {
    nav: {
      home: 'الرئيسية',
      services: 'خدماتنا',
      about: 'من نحن',
      contact: 'اتصل بنا',
      langLabel: 'English',
    },
    hero: {
      title: 'شريكك الموثوق لتخليص المعاملات في الإمارات',
      subtitle: 'نقدم حلولاً متكاملة لتأسيس الشركات وخدمات رجال الأعمال وتخليص المعاملات الحكومية في أبوظبي.',
      ctaPrimary: 'اكتشف خدماتنا',
      ctaSecondary: 'تواصل معنا',
    },
    trust: {
      title: 'موثوقون لدى الجهات الحكومية',
    },
    services: {
      title: 'خدماتنا المتميزة',
      subtitle: 'حلول شاملة للأفراد والشركات بأعلى معايير الجودة.',
      items: [
        {
          id: 's1',
          icon: Building2,
          title: 'تأسيس الشركات',
          description: 'مساعدة كاملة في إصدار الرخص التجارية والموافقات وتأسيس الشركات في البر الرئيسي والمناطق الحرة.',
        },
        {
          id: 's2',
          icon: FileText,
          title: 'خدمات المندوب (PRO)',
          description: 'تخليص معاملات تصاريح العمل وعقود التوظيف وبطاقات العمل مع وزارة الموارد البشرية والتوطين (تسهيل).',
        },
        {
          id: 's3',
          icon: ShieldCheck,
          title: 'التأشيرات والإقامة',
          description: 'إجراءات سريعة للإقامة الذهبية وتأشيرات الإقامة وكفالة الأسرة.',
        },
        {
          id: 's4',
          icon: Globe,
          title: 'خدمات الجوازات',
          description: 'متابعة تجديد الجوازات والوثائق الرسمية لمختلف الجنسيات.',
        },
        {
          id: 's5',
          icon: Scale,
          title: 'الترجمة القانونية',
          description: 'خدمات ترجمة معتمدة لجميع الوثائق الرسمية المطلوبة من المحاكم والوزارات.',
        },
        {
          id: 's6',
          icon: Briefcase,
          title: 'الدعم المؤسسي',
          description: 'دعم مستمر لفتح الحسابات المصرفية للشركات والامتثال الحكومي.',
        },
      ],
    },
    about: {
      title: 'عن آسيا لخدمات الأعمال',
      subtitle: 'التميز، النزاهة، والكفاءة',
      description1: 'تعتبر "آسيا لخدمات الأعمال" شركة رائدة في مجال تخليص المعاملات وتسهيل الأعمال ومقرها أبوظبي. نحن نعمل كجسر وصل بين الشركات والجهات الحكومية لضمان سير العمليات بسلاسة وامتثال تام.',
      description2: 'بفضل سنوات من الخبرة وفريق من المحترفين المتفانين، نفهم تفاصيل قوانين العمل وإجراءات الهجرة في الإمارات. نحن فخورون بأننا مرخصون وموثوقون من قبل جهات حكومية متعددة.',
      stats: [
        { label: 'سنوات الخبرة', value: '+10' },
        { label: 'عميل سعيد', value: '+500' },
        { label: 'معاملة ناجحة', value: '+10k' },
      ],
    },
    contact: {
      title: 'تواصل معنا',
      subtitle: 'تفضل بزيارة مكتبنا أو أرسل لنا رسالة.',
      form: {
        name: 'الاسم الكامل',
        email: 'البريد الإلكتروني',
        phone: 'رقم الهاتف',
        message: 'رسالتك',
        submit: 'إرسال الرسالة',
      },
      info: {
        addressLabel: 'موقعنا',
        address: 'شارع الفلاح، أبوظبي، الإمارات العربية المتحدة',
        phoneLabel: 'اتصل بنا',
        emailLabel: 'راسلنا',
      },
    },
    footer: {
      company: 'آسيا لخدمات الأعمال',
      description: 'بوابتك لخدمات حكومية سلسة في الإمارات العربية المتحدة.',
      rights: '© 2024 آسيا لخدمات الأعمال. جميع الحقوق محفوظة.',
    },
  },
};